<?php get_header(); ?>

			<div id="content">
			<?php
					global $wp_query;
					$count = $wp_query->post_count;
 			?>
			
				<section class="heading-search">
					<div id="inner-content" class="wrap cf">
						<div class="m-all t-all d-all cf">
						<h1 class="archive-title"><span class="searchtitle">Articles Tagged: </span><span class="searchtitlequery"><?php single_cat_title(''); ?></span></h1>	
					
						<?php
							
							the_archive_description( '<div class="taxonomy-description">', '</div>' );
							?>
							
							<p>Showing <?php echo $count;?> of <?php echo $wp_query->found_posts; ?> Results</p>
							
							
						</div>
					</div>
				</section>
				<div id="inner-content" class="wrap wrap-home-wide cf">
					
			
						<main id="main" class="m-all t-all d-all cf" role="main" itemscope itemprop="mainContentOfPage" itemtype="http://schema.org/Blog">

							
							
							<ul class="block-std block-std-3">	
								
								


								<?php  $countpost = 0; ?>
							<?php if (have_posts()) : while (have_posts()) : the_post(); 
								$featuredImage = wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
							    $post_type = get_post_type_object( get_post_type($post) );
							    $shortdescription = get_post_meta($post->ID, 'wpcf-short-description', true);
							    $largeimg = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'large', false, '' );
								$largeimgsrc = $largeimg[0];
							     $countpost++;
							?>

								
							<?php if( get_post_type() == 'fashion-post' ) { ?>
												 <li class="block-fashion">										
											<?php } else if( get_post_type() == 'beauty-post' ) { ?>
												 <li class="block-beauty">									
											<?php } else if( get_post_type() == 'art' ) { ?>
												 <li class="block-art">										
											<?php } else if( get_post_type() == 'lifestyle-post' ) { ?>
												 <li class="block-lifestyle">										
											<?php } else if( get_post_type() == 'adulting-post' ) { ?>
												 <li class="block-adulting">										
											<?php } else if( get_post_type() == 'video' ) { ?>
												 <li class="block-video">
											<?php } else { ?>
												 <li>
											<?php } ?>
									  
									  
									  
						 	
						 	<?php
				                if(has_post_thumbnail()) { ?>
				                  
								 <a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>">

								<div id="blockimagecontainer">
									<?php 
										if( $design == 2 ) { ?>
										    <span class="videotag">Video</span>
										<?php } ?>

<div id="blockimage" style="background-image: url('<?php echo $largeimgsrc; ?>');"></div></div></a>		 
				
				            <?php } else { ?>
				             
				             	<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><div id="blockimagecontainer">
					             	<?php 
										if( $design == 2 ) { ?>
										    <span class="videotag">Video</span>
										<?php } ?>
										<div id="blockimage"></div></div></a>	

				            <?php } ?>



							<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><article id="post-<?php the_ID(); ?>" <?php post_class( 'cf' ); ?> role="article">	            
									
									<h2 class="entry-title"><?php the_title(); ?></h2>
									

								
									<?php if ( ! has_excerpt() ) { ?>
										 <section class="block-excerpt"><?php the_excerpt(); ?></section> 
										<? } else {  ?>
										      <section class="block-excerpt"><?php the_excerpt(); ?></section> 
										<?php } ?>
								
								
								
								<p class="byline entry-meta vcard">
									
									<?php $countterm = 1; ?>
										<?php if( get_post_type() == 'fashion-post' ) { ?>
											<?php $term_list = wp_get_post_terms($post->ID, 'fashion-category'); ?>
										<?php } else if( get_post_type() == 'beauty-post' ) { ?>
											<?php $term_list = wp_get_post_terms($post->ID, 'beauty-category'); ?>
										<?php } else if( get_post_type() == 'art' ) { ?>
											<?php $term_list = wp_get_post_terms($post->ID, 'art-category'); ?>
										<?php } else if( get_post_type() == 'lifestyle-post' ) { ?>
											<?php $term_list = wp_get_post_terms($post->ID, 'lifestyle-category'); ?>
										<?php } else if( get_post_type() == 'adulting-post' ) { ?>
											<?php $term_list = wp_get_post_terms($post->ID, 'adulting-category'); ?>
										<?php } else if( get_post_type() == 'video' ) { ?>
											<?php $term_list = wp_get_post_terms($post->ID, 'video-category'); ?>
										<?php } else { ?>
										<?php $term_list = wp_get_post_terms($post->ID, 'category'); ?>
										<?php } ?>
										
										
										
												
										
										<?php if( get_post_type() == 'fashion-post'){ ?>
											<?php 	echo '<a href="';
													echo get_home_url();
													echo '/fashion';
													echo '">';
													echo '<span>' . 'Fashion' . '</span>';
													echo '</a>';
												?>
										<?php } else if (get_post_type() == 'beauty-post'){ ?>
											<?php 	echo '<a href="';
													echo get_home_url();
													echo '/beauty';
													echo '">';
													echo '<span>' . 'Beauty' . '</span>';
													echo '</a>';
												?>
										<?php } else if ( get_post_type() == 'arts-post'){ ?>
											<?php 	echo '<a href="';
													echo get_home_url();
													echo '/arts';
													echo '">';
													echo '<span>' . 'Arts' . '</span>';
													echo '</a>';
												?>
										<?php } else if (get_post_type() == 'lifestyle-post'){ ?>
											<?php 	echo '<a href="';
													echo get_home_url();
													echo '/lifestyle';
													echo '">';
													echo '<span>' . 'Lifestyle' . '</span>';
													echo '</a>';
												?>
										<?php } else if (get_post_type() == 'adulting-post'){ ?>
											<?php 	echo '<a href="';
													echo get_home_url();
													echo '/adulting';
													echo '">';
													echo '<span>' . 'Adulting' . '</span>';
													echo '</a>';
												?>
										<?php } else if (get_post_type() == 'video'){ ?>
											<?php 	echo '<a href="';
													echo get_home_url();
													echo '/video';
													echo '">';
													echo '<span>' . 'Video' . '</span>';
													echo '</a>';
												?>
										<?php } else { ?>
											<?php
												if ( ! empty( $term_list ) && ! is_wp_error( $term_list ) ){
												    foreach ( $term_list as $term ) { 
													 	$term_link = get_term_link( $term );
													    // If there was an error, continue to the next term.
													    if ( is_wp_error( $term_link ) ) {
													        continue;
													    } 
														 echo '<a href="' . esc_url( $term_link ) . '">';   
														 echo '<span>' . $term->name . '</span>';
														 echo '</a>';		
												    }
												}
											?>
										<?php } ?>


										<?php $countterm = 1; ?>
                                     <span class="time"><?php the_time('F j, Y'); ?></span>
									</p>
							</article></a>
							
							
										  </li>	
							<?php endwhile; ?>

									<?php bones_page_navi(); ?>

							<?php else : ?>

									<?php include('template-notfound.php');?>

							<?php endif; ?>
							
							<form role="search" method="get" id="searchform2" action="<?php echo home_url( '/' ); ?>">
					<input id="searchinput2" class="sb-search-input" placeholder="Can't find something? Search again" type="text" value="" name="s" id="s">
					<input class="sb-search-submit" type="submit" value="">
					<input type="hidden" name="post_type" value="all" />
					
					
				</form>



							
							</ul>

						</main>
						
						<div class="m-all t-1of3 d-1of3 cf last-col">
						
				</div>
				
				

				</div>

			</div>
			<section class="footer-sidebar">
					<div id="inner-content" class="wrap wrap-home-wide cf">
					<div id="sidebar-all" class="m-all t-all d-all cf">
						<?php get_sidebar('category'); ?>



						</div>
					</div>
				</section>

<?php get_footer(); ?>
