<?php 
	$featuredImage = wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
	$design = get_post_meta($post->ID, 'wpcf-article-design', true); 
	$vidtype = get_post_meta($post->ID, 'wpcf-video-type', true);
	$vidyoutube = get_post_meta($post->ID, 'wpcf-video-youtube-link', true);
	$vidvimeo = get_post_meta($post->ID, 'wpcf-video-vimeo-link', true);
	$headertype = get_post_meta($post->ID, 'wpcf-header-type', true);
	$post_type_name = get_post_type( $post->ID );
	$post_type = get_post_type_object( get_post_type($post) );
	$embed_code = wp_oembed_get($vidyoutube);
	$embed_code2 = wp_oembed_get($vidvimeo);
	$titlefonts = get_post_meta($post->ID, 'wpcf-article-title-fonts', true);
	$titlecolor = get_post_meta($post->ID, 'wpcf-article-title-color', true);
	$bgshadow = get_post_meta($post->ID, 'wpcf-background-shadow', true);
?>

<?php if(($design == '4')&&($headertype == '2')){ ?> <!-- HEADER BLACK -->

<header class="header cd-header cd-header-black" role="banner" itemscope itemtype="http://schema.org/WPHeader">

<?php } else if (($design == '4')&&($headertype == '3')){?> <!-- HEADER WHITE -->

<header class="header cd-header cd-header-white" role="banner" itemscope itemtype="http://schema.org/WPHeader">
	
<?php } else {?> <!-- HEADER TRANSPARENT -->

<header class="header cd-header cd-header-trans" role="banner" itemscope itemtype="http://schema.org/WPHeader">
	
<?php } ?>



				<div id="inner-header" class="inner-header-appear">
				
					<?php // to use a image just replace the bloginfo('name') with your img src and remove the surrounding <p> ?>
					
					<div class="header-top">
					<p id="logo" itemscope itemtype="http://schema.org/Organization"><a href="<?php echo home_url(); ?>" rel="nofollow">
					<?php if (($design == '4')&&($headertype == '3')){ ?>
					<img src="<?php bloginfo( 'template_url' ); ?>/library/images/foxesden-logo-black.png" />
					<?php } else { ?>
					<img src="<?php bloginfo( 'template_url' ); ?>/library/images/foxesden-logo-white.png" />
					<?php } ?>
					</a></p>

					<?php // if you'd like to use the site description you can un-comment it below ?>
					<?php // bloginfo('description'); ?>

					
					<nav class="nav nav-desktop" role="navigation" itemscope itemtype="http://schema.org/SiteNavigationElement">
							<?php wp_nav_menu(array(
    					         'container' => false,                           // remove nav container
    					         'container_class' => 'menu cf',                 // class of container (should you choose to use it)
    					         'menu' => __( 'The Main Menu', 'bonestheme' ),  // nav name
    					         'menu_class' => 'nav top-nav cf',               // adding custom nav class
    					         'theme_location' => 'main-nav',                 // where it's located in the theme
    					         'before' => '',                                 // before the menu
        			               'after' => '',                                  // after the menu
        			               'link_before' => '',                            // before each link
        			               'link_after' => '',                             // after each link
        			               'depth' => 0,                                   // limit the depth of the nav
    					         'fallback_cb' => ''                             // fallback function (if there is one)
						)); ?>

					</nav>
					
					
					<div class="subscribe">
						<ul>
							<li><a href="<?php echo get_home_url(); ?>/join-us">Contribute</a></li>
						</ul>
						
					</div>
					<button id="searchtrigger" class="md-trigger md-trigger-white" data-modal="modal-7">
						</button>
					
					
					</div>
					
				</div>
				
					<a id="menubutton" class="cd-primary-nav-trigger" href="#0">
						<span class="cd-menu-text cd-menu-text">Menu</span><span class="cd-menu-icon cd-menu-icon"></span>
					</a> <!-- cd-primary-nav-trigger -->
			</header>
			
			<nav class="nav nav-mobile" role="navigation" itemscope itemtype="http://schema.org/SiteNavigationElement">
				
					<ul class="cd-primary-nav">
						<div class="cd-primary-nav-header">
							<span>Navigate</span>
						<a id="menubutton" class="cd-primary-nav-trigger menubutton-trans" href="#0">
						</a>
						</div>
						<span></span>
					</a> <!-- cd-primary-nav-trigger -->
							<?php wp_nav_menu(array(
    					         'container' => false,                           // remove nav container
    					         'container_class' => '',                 // class of container (should you choose to use it)
    					         'menu' 			=> 'MobileNav' ,  // nav name
    					         'menu_class' => 'mobile-nav',               // adding custom nav class
    					         'theme_location' => 'main-nav'               // where it's located in the theme
						)); ?>
						
						<?php wp_nav_menu(array(
    					         'container' => false,                           // remove nav container
    					         'container_class' => '',                 // class of container (should you choose to use it)
    					         'menu' 			=> 'MobileNav2' ,  // nav name
    					         'menu_class' => 'mobile-nav-2',               // adding custom nav class
    					         'theme_location' => 'main-nav'               // where it's located in the theme
						)); ?>

						
					</ul>
					
					</nav>