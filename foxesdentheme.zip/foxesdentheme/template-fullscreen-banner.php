<?php
							
	$args = array( 'posts_per_page' => 1, 'order'=> 'ASC', 'orderby' => 'date','post_type' => 'custom_type', 'custom_cat' => 'fullscreen-banner' );
	$postslist = get_posts( $args );
	foreach ( $postslist as $post ) :
	$adtype = get_post_meta($post->ID, 'wpcf-ad-type', true); 
	$adfullscreenimg = get_post_meta($post->ID, 'wpcf-ad-fullscreen-image', true); 
	$adfullscreenlink = get_post_meta($post->ID, 'wpcf-ad-fullscreen-link', true); 
	$adlinktitle = get_post_meta($post->ID, 'wpcf-ad-link-title', true); 
	$adfullscreenlargeimg = get_post_meta($post->ID, 'wpcf-ad-fullscreen-large-image', true);
							  setup_postdata( $post ); ?> 
							
						 <?php if( $adtype == 2 ) { ?>
						
						<section class="ad-fullscreen" style="background-image: url('<?php echo $adfullscreenimg; ?>');">
							<a href="<?php echo $adfullscreenlink; ?>" title="<?php echo $adlinktitle;?>"><div class="ad-fullscreen-content"> 
							
							</div></a>
						</section>

							<?php } else if($adtype == 3) { ?>
								<section class="ad-fullscreen-large" style="background-image: url('<?php echo $adfullscreenlargeimg; ?>');">
							<a href="<?php echo $adfullscreenlargelink; ?>" title="<?php echo $adlinktitle;?>"><div class="ad-fullscreen-content"> 
							
							</div></a>
						</section>
						
							<?php } else { ?>
						
							<?php } ?>
							
							
								
	<?php
	endforeach; 
	wp_reset_postdata();
	?>	