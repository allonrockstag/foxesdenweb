<?php get_header(); ?>

			<div id="content">
			<?php
					global $wp_query;
 			?>
			
				<div class="category-header category-header-video">
					<div id="inner-content" class="wrap cf">
						<div class="m-all t-all d-all cf">
						<h4><a href="<?php echo get_home_url(); ?>/videos">All Videos</a></h4>
						<h1 class="page-title page-title-2"><span class="tag-label">Video Playlist:</span></a> <?php single_cat_title(''); ?></h1>
						<?php
							
							the_archive_description( '<div class="taxonomy-description">', '</div>' );
							?>
						</div>
					</div>
				</div>
				<div id="inner-content" class="wrap cf">
					
			
						<main id="main" class="m-all t-all d-all cf" role="main" itemscope itemprop="mainContentOfPage" itemtype="http://schema.org/Blog">
							
							
							
							<ul class="video-list video-list-2">	
								
								<div class="taxonomy-results"><?php echo $wp_query->found_posts; ?> Videos</div>
								

								<?php  $countpost = 0; ?>
							<?php if (have_posts()) : while (have_posts()) : the_post(); 
								$featuredImage = wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
							    $post_type = get_post_type_object( get_post_type($post) );
							    $shortdescription = get_post_meta($post->ID, 'wpcf-short-description', true);
							    $largeimg = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'large', false, '' );
								$largeimgsrc = $largeimg[0];
							     $countpost++;
							?>

						   <li class="list-item list-item-2">
				             
				            <?php
				                if(has_post_thumbnail()) { ?>
				<div id="backgroundimg" style="background-image: url('<?php echo $largeimgsrc; ?>');"></div>
				            <?php } else { ?>
				             
								<div id="backgroundimg"></div>
				            <?php } ?>
	
								
								
								<a id="list-item-text" href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>">
									
								<article>
								<h3><?php the_title(); ?></h3>
								<p class="byline entry-meta vcard">
								<span class="watch">Watch Now</span>
								</p>
								</article>
								
								</a>
								
				            </li>
				            



							<?php endwhile; ?>

									<?php bones_page_navi(); ?>

							<?php else : ?>

									<article id="post-not-found" class="hentry cf">
										<header class="article-header">
											<img src="<?php echo get_template_directory_uri(); ?>/library/images/kopifolks-404.png">
								<h1><?php _e( 'No Content Found.. but we have a burger!', 'bonestheme' ); ?></h1>
										</header>
										<section class="entry-content">
											<p><?php _e( 'We are working on adding more content here in the future. Stay tuned for more!', 'bonestheme' ); ?></p>
											<address>Icon made by <a href="http://www.freepik.com/">Freepik</a> from www.flaticon.com</address>
										</section>
										
									</article>

							<?php endif; ?>
							
							</ul>

						</main>
				
				
				

				</div>

			</div>

<?php get_footer(); ?>
