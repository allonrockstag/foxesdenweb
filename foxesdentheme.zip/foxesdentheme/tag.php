<?php get_header(); ?>

			<div id="content">
			
			
				<div class="category-header">
					<div id="inner-content" class="wrap cf">
						<div class="m-all t-all d-all cf">
							
						<h1 class="page-title"><span class="tag-label">Articles Tagged:</span>
							<?php single_cat_title(''); ?></h1>
						<?php
							
							the_archive_description( '<div class="taxonomy-description">', '</div>' );
							?>
							<p>Showing <?php echo $wp_query->found_posts; ?> Results</p>
						</div>
					</div>
				</div>
				<div id="inner-content" class="wrap wrap-home-wide cf">
					
			
						<main id="main" class="m-all t-all d-all cf" role="main" itemscope itemprop="mainContentOfPage" itemtype="http://schema.org/Blog">

							
							
							<ul class="block-std block-std-3">	
								
								


								<?php  $countpost = 0; ?>
							<?php if (have_posts()) : while (have_posts()) : the_post(); 
								$featuredImage = wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
							    $post_type = get_post_type_object( get_post_type($post) );
							    $shortdescription = get_post_meta($post->ID, 'wpcf-short-description', true);
							     $countpost++;
							?>

							<li>
									  
									  
									  
						 	
						 	<?php
				                if(has_post_thumbnail()) { ?>
				                  
								 <a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>">

								<div id="blockimagecontainer">
									<?php 
										if( $design == 2 ) { ?>
										    <span class="videotag">Video</span>
										<?php } ?>

<div id="blockimage" style="background-image: url('<?php echo $featuredImage; ?>');"></div></div></a>		 
				
				            <?php } else { ?>
				             
				             	<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><div id="blockimagecontainer">
					             	<?php 
										if( $design == 2 ) { ?>
										    <span class="videotag">Video</span>
										<?php } ?>
										<div id="blockimage"></div></div></a>	

				            <?php } ?>



							<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><article id="post-<?php the_ID(); ?>" <?php post_class( 'cf' ); ?> role="article">	            
									
									<h2 class="entry-title"><?php the_title(); ?></h2>
									

								
									<?php if ( ! has_excerpt() ) { ?>
										 <section class="block-excerpt"><?php the_excerpt(); ?></section> 
										<? } else {  ?>
										      <section class="block-excerpt"><?php the_excerpt(); ?></section> 
										<?php } ?>
								
								
								
								<p class="byline entry-meta vcard">
										
									<?php $countterm = 1; ?>
										<?php if( get_post_type() == 'feature' ) { ?>
											<?php $term_list = wp_get_post_terms($post->ID, 'feature-type'); ?>
										<?php } else if( get_post_type() == 'guide' ) { ?>
										<?php $term_list = wp_get_post_terms($post->ID, 'category'); ?>
										<?php } else { ?>
										<?php $term_list = wp_get_post_terms($post->ID, 'category'); ?>
										<?php } ?>
										
										<?php if( get_post_type() == 'guide' ) { ?>
											<?php 	echo '<a href="';
													echo get_home_url();
													echo '/food-guide';
													echo '">';
													echo '<span>' . 'Food Guide' . '</span>';
													echo '</a>';
												?>
										<?php } else if( get_post_type() == 'feature' ) { ?>
											<?php 	echo '<a href="';
													echo get_home_url();
													echo '/featured';
													echo '">';
													echo '<span>' . 'Featured' . '</span>';
													echo '</a>';
												?>
										<?php } else if( get_post_type() == 'video' ) { ?>
											<?php 	echo '<a href="';
													echo get_home_url();
													echo '/video';
													echo '">';
													echo '<span>' . 'Video' . '</span>';
													echo '</a>';
												?>
										<?php } else { ?>
											
											<?php
												if ( ! empty( $term_list ) && ! is_wp_error( $term_list ) ){
												    foreach ( $term_list as $term ) { 
													 	$term_link = get_term_link( $term );
													    // If there was an error, continue to the next term.
													    if ( is_wp_error( $term_link ) ) {
													        continue;
													    } 
														 echo '<a href="' . esc_url( $term_link ) . '">';   
														 echo '<span>' . $term->name . '</span>';
														 echo '</a>';		
												    }
												}
											?>
										<?php } ?>
										<?php $countterm = 1; ?>
                                     <span class="time"><?php the_time('F j, Y'); ?></span>
									</p>
							</article></a>
							
							
										  </li>


							<?php endwhile; ?>

									<?php bones_page_navi(); ?>

							<?php else : ?>

									<article id="post-not-found" class="hentry cf">
										<header class="article-header">
											<img src="<?php echo get_template_directory_uri(); ?>/library/images/kopifolks-404.png">
								<h1><?php _e( 'No Content Found.. but we have a burger!', 'bonestheme' ); ?></h1>
										</header>
										<section class="entry-content">
											<p><?php _e( 'We are working on adding more content here in the future. Stay tuned for more!', 'bonestheme' ); ?></p>
											<address>Icon made by <a href="http://www.freepik.com/">Freepik</a> from www.flaticon.com</address>
										</section>
										
									</article>

							<?php endif; ?>
							
							<form role="search" method="get" id="searchform2" action="<?php echo home_url( '/' ); ?>">
					<input id="searchinput2" class="sb-search-input" placeholder="Can't find something? Search again" type="text" value="" name="s" id="s">
					<input class="sb-search-submit" type="submit" value="">
					<input type="hidden" name="post_type" value="all" />
					
					
				</form>



							
							</ul>

						</main>
						
						<div class="m-all t-1of3 d-1of3 cf last-col">
						
				</div>
				
				

				</div>

			</div>

<?php get_footer(); ?>
