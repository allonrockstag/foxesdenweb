<?php if (have_posts()) : while (have_posts()) : the_post();
	$featuredImage = wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
	$design = get_post_meta($post->ID, 'wpcf-article-design', true); 
	$vidtype = get_post_meta($post->ID, 'wpcf-video-type', true);
	$vidyoutube = get_post_meta($post->ID, 'wpcf-video-youtube-link', true);
	$vidvimeo = get_post_meta($post->ID, 'wpcf-video-vimeo-link', true);
	$post_type_name = get_post_type( $post->ID );
	$post_type = get_post_type_object( get_post_type($post) );
	$embed_code = wp_oembed_get($vidyoutube);
	$embed_code2 = wp_oembed_get($vidvimeo);
	
	$headertype = get_post_meta($post->ID, 'wpcf-header-type', true);
	$titlefonts = get_post_meta($post->ID, 'wpcf-article-title-fonts', true);
	$titlecolor = get_post_meta($post->ID, 'wpcf-article-title-color', true);
	$bgshadow = get_post_meta($post->ID, 'wpcf-background-shadow', true);
	
	$loop = new WP_Query( array( 'post_type' => array('post','what-to-eat','feature'), 'posts_per_page' => 3, 'ignore_sticky_posts' => 1, 'post__not_in' => array( $post->ID ), 'paged' => $paged ) );
	
	?>
	<?php if($design == '4'){ ?>
				<?php get_header('fullwidth'); ?>
			<div id="content" class="nopadding">	
				
				
	            
	            
	<?php } elseif($design == '3'){ ?>
			<?php get_header(); ?>					
			<div id="content">		            
	             			
	<?php } elseif ($design == '2'){ ?>
			<?php get_header(); ?>
			
			
			<?php // Calling Youtube Data API.
				
				
				
$subscribers = file_get_contents('https://www.googleapis.com/youtube/v3/channels?part=statistics&id=UCdjmRNHp3aOm4_zhOrNxhPg&key=AIzaSyCnCIR_B3hJHTNS18FtQkAVnKsoPpHHKDs');
// Decoding json response
$response = json_decode($subscribers, true );
// echoing subscribers count.
 $api_response_decoded = intval($response['items'][0]['statistics']['subscriberCount']);
 
 
// GET YOUTUBE ID
$url = $vidyoutube;
parse_str( parse_url( $url, PHP_URL_QUERY ), $my_array_of_vars );
$videoid = $my_array_of_vars['v'];
$apikey = 'AIzaSyCnCIR_B3hJHTNS18FtQkAVnKsoPpHHKDs';
 
 //GET VIDEO TITLE
$json = file_get_contents('https://www.googleapis.com/youtube/v3/videos?id='.$videoid.'&key='.$apikey.'&part=snippet');
$json2 = file_get_contents('https://www.googleapis.com/youtube/v3/videos?id='.$videoid.'&key='.$apikey.'&part=statistics');
$ytdata = json_decode($json);
$json_data = json_decode($json2, true);
$views = $json_data['items'][0]['statistics']['viewCount'];
 ?>


			<div id="content">
	      
				
	<?php } else { ?>
	
			<?php get_header(); ?>					
			<div id="content">
		 <?php }?>
							
	<?php endwhile; ?>
<?php else : ?>
<?php endif; ?>

			
				<?php if($design == '2' || $design == '3' || $design == '4'){ ?>
						
				<?php } else { ?>
										
				<?php } ?>
	
		
					<?php if($design == '4'){ ?>
						<section class="post-hero-background"> 
							<?php if(has_post_thumbnail()) { ?>
				         <?php $featuredImage = wp_get_attachment_url( get_post_thumbnail_id($post->ID) ); ?>
				         <section class="post-hero-fullwidth" style="background-image:url(<?php echo $featuredImage; ?>);">
					         
					          <?php if (($design == '4')&&($bgshadow == '2')){?> <!-- NO SHADOW -->
							         <div class="hero-fullwidth-container hero-fullwidth-container-no-shadow">
								         
								        <?php } else { ?>
								         <div class="hero-fullwidth-container">
								        
								        <?php } ?>
								         <div class="hero-fullwidth-content">
								         <div class="hero-fullwidth-title">
									         <?php if (($design == '4')&&($titlecolor == '2')){?> <!-- BLACK TITLE -->
									         <span class="blacktitle">
									         <?php } else { ?>
										       <span>
									         <?php } ?>
						
                   <?php if (($design == '4')&&($titlefonts == '2')){?> <!-- UNNA FONT -->
				   		<h1 class="entry-title single-title single-title-unna" itemprop="headline" rel="bookmark"><?php the_title(); ?></h1>
                  <?php } else { ?> <!-- THIRD RAIL FONT -->
                  		<h1 class="entry-title single-title" itemprop="headline" rel="bookmark"><?php the_title(); ?></h1>
                  <?php } ?>
				                  
				                  <?php if ( has_excerpt() ) { ?>
									    <p class="excerpt"><?php echo get_the_excerpt(); ?></p>
									<?php } else { ?>
									    
									<?php } ?>
									
									
										<a href="#thearticle">
											<?php if (($design == '4')&&($titlecolor == '2')){?> <!-- BLACK TITLE -->
											<img src="<?php echo get_template_directory_uri(); ?>/library/images/arrow_down_black.png">
											
											<?php } else { ?>
											<img src="<?php echo get_template_directory_uri(); ?>/library/images/arrow_down_white.png">
											<?php } ?>
											</a>
									         </span>
									
								         </div>
							
					
							         </div>
						         </div>
				         </section>
				         </section>	
				        
			            <?php } ?>
	            
	            
						<?php } ?> <!-- end if-->
	            
	            	
													
						<?php if($design == '4'){ ?>
								<main id="main" class="fullwidth-main-body" role="main" itemscope itemprop="mainContentOfPage" itemtype="http://schema.org/Blog">
						<?php } else {  ?>
								<div id="inner-content" class="wrap wrap-post cf">	
									
									
																	
								
								<main id="main" role="main" itemscope itemprop="mainContentOfPage" itemtype="http://schema.org/Blog">
						<?php }	 ?>
							
					
						

						<?php if (have_posts()) : while (have_posts()) : the_post();
							$featuredImage = wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
	$design = get_post_meta($post->ID, 'wpcf-article-design', true); 
	$vidtype = get_post_meta($post->ID, 'wpcf-video-type', true);
	$vidyoutube = get_post_meta($post->ID, 'wpcf-video-youtube-link', true);
	$vidvimeo = get_post_meta($post->ID, 'wpcf-video-vimeo-link', true);
	$headertype = get_post_meta($post->ID, 'wpcf-header-type', true);
	$post_type_name = get_post_type( $post->ID );
	$post_type = get_post_type_object( get_post_type($post) );
	$embed_code = wp_oembed_get($vidyoutube);
	$embed_code2 = wp_oembed_get($vidvimeo);
	$titlefonts = get_post_meta($post->ID, 'wpcf-article-title-fonts', true);
	$titlecolor = get_post_meta($post->ID, 'wpcf-article-title-color', true);
	$bgshadow = get_post_meta($post->ID, 'wpcf-background-shadow', true);						
							 ?>
							 
							
						
							<?php if($design == '3'){ ?>
								<?php get_template_part( 'post-design/format-huge', get_post_format() ); ?>
							
							<?php } else if ($design == '4'){ ?>
								<?php get_template_part( 'post-design/format-fullwidth', get_post_format() ); ?>
							<?php } else { ?>
								<?php
								/*
								 * Ah, post formats. Nature's greatest mystery (aside from the sloth).
								 *
								 * So this function will bring in the needed template file depending on what the post
								 * format is. The different post formats are located in the post-formats folder.
								 *
								 *
								 * REMEMBER TO ALWAYS HAVE A DEFAULT ONE NAMED "format.php" FOR POSTS THAT AREN'T
								 * A SPECIFIC POST FORMAT.
								 *
								 * If you want to remove post formats, just delete the post-formats folder and
								 * replace the function below with the contents of the "format.php" file.
								*/
								get_template_part( 'post-formats/format', get_post_format() );
							?>
							
							
							<?php } ?>
							
							


							
							
							
							<div class="post-bottom-bar">
								<ul class="post-share-mobile">
					  	<li class="share-fb"><a href="http://www.facebook.com/sharer.php?u=<?php echo get_permalink(); ?>" target="_blank"><span></span></a></li>
					  	<li class="share-twitter"><a href="https://twitter.com/share?url=<?php echo get_permalink(); ?>" target="_blank"><span></span></a></li>
					  	<li class="share-pinterest"><a href="http://pinterest.com/pin/create/button/?url=<?php echo get_permalink(); ?>&media=<?php echo $featuredImage; ?>&description=<?php the_title();?>" target="_blank"><span></span></a></li>
<li class="share-comment"><a href="#comment"><span>Comments</span></a></li>


				  	</ul>
							</div>

						<?php endwhile; ?>

						<?php else : ?>

							<article id="post-not-found" class="hentry cf">
									<header class="article-header">
										<h1><?php _e( 'Oops, Post Not Found!', 'bonestheme' ); ?></h1>
									</header>
									<section class="entry-content">
										<p><?php _e( 'Uh Oh. Something is missing. Try double checking things.', 'bonestheme' ); ?></p>
									</section>
									<footer class="article-footer">
											<p><?php _e( 'This is the error message in the single.php template.', 'bonestheme' ); ?></p>
									</footer>
							</article>

						<?php endif; ?>

						
						
							<?php if($design == '4'){ ?>
								</main>					
								
								<?php } else {  ?>
								</main>
								</div>
						<?php }	 ?>				
					
					
				
				
				<?php include('template-morearticles.php');?>

			</div> <!-- end #content -->
			

			<!-- Root element of PhotoSwipe. Must have class pswp. -->
<div class="pswp" tabindex="-1" role="dialog" aria-hidden="true">

    <!-- Background of PhotoSwipe. 
         It's a separate element as animating opacity is faster than rgba(). -->
    <div class="pswp__bg"></div>

    <!-- Slides wrapper with overflow:hidden. -->
    <div class="pswp__scroll-wrap">

        <!-- Container that holds slides. 
            PhotoSwipe keeps only 3 of them in the DOM to save memory.
            Don't modify these 3 pswp__item elements, data is added later on. -->
        <div class="pswp__container">
            <div class="pswp__item"></div>
            <div class="pswp__item"></div>
            <div class="pswp__item"></div>
        </div>

        <!-- Default (PhotoSwipeUI_Default) interface on top of sliding area. Can be changed. -->
        <div class="pswp__ui pswp__ui--hidden">

            <div class="pswp__top-bar">

                <!--  Controls are self-explanatory. Order can be changed. -->

                <div class="pswp__counter"></div>

                <button class="pswp__button pswp__button--close" title="Close (Esc)"></button>

                <button class="pswp__button pswp__button--share" title="Share"></button>

                <button class="pswp__button pswp__button--fs" title="Toggle fullscreen"></button>

                <button class="pswp__button pswp__button--zoom" title="Zoom in/out"></button>

                <!-- Preloader demo http://codepen.io/dimsemenov/pen/yyBWoR -->
                <!-- element will get class pswp__preloader--active when preloader is running -->
                <div class="pswp__preloader">
                    <div class="pswp__preloader__icn">
                      <div class="pswp__preloader__cut">
                        <div class="pswp__preloader__donut"></div>
                      </div>
                    </div>
                </div>
            </div>

            <div class="pswp__share-modal pswp__share-modal--hidden pswp__single-tap">
                <div class="pswp__share-tooltip"></div> 
            </div>

            <button class="pswp__button pswp__button--arrow--left" title="Previous (arrow left)">
            </button>

            <button class="pswp__button pswp__button--arrow--right" title="Next (arrow right)">
            </button>

            <div class="pswp__caption">
                <div class="pswp__caption__center"></div>
            </div>

        </div>

    </div>

</div>



<?php get_footer(); ?>


