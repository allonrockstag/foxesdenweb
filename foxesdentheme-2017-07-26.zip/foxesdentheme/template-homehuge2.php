<section class="homehuge">
				
								<?php
									$countpost = 0;
									$sticky_posts = get_option( 'sticky_posts' );
									$args = array(
									'posts_per_page' => 1,
									'order'=> 'DESC',
									'orderby' => 'date',
									'post_type' => array('post','fashion-post','beauty-post','art','lifestyle-post','adulting-post'),
									'post__in'  => $sticky_posts,
									'ignore_sticky_posts' => 1,
									'offset' => 0 );
									$postslist = get_posts( $args );
									foreach ( $postslist as $post ) :
									$featuredImage = wp_get_attachment_url( get_post_thumbnail_id($post->ID));
									$design = get_post_meta($post->ID, 'wpcf-article-design', true); 
									$largeimg = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'large', false, '' );
									$largeimgsrc = $largeimg[0]; 
									 $countpost++;
									  setup_postdata( $post ); ?> 

									     	<?php $post1 = get_the_ID(); ?>

									
							<?php
				                if(has_post_thumbnail()) { ?>
				                 <div class="homehuge1" style="background-image: url('<?php echo $featuredImage; ?>');">
				                 <?php } else { ?>
				                  <div class="homehuge1">
				                 <?php } ?>
				                 
				                 
								 	
								 	 <?php if (($design == '4')&&($bgshadow == '2')){?> <!-- NO SHADOW -->
							         <div class="hero-fullwidth-container hero-fullwidth-container-no-shadow">
								         
								        <?php } else { ?>
								         <div class="homehuge1-container">
								        
								        <?php } ?>
								        
								        <div class="homehuge1-content">
								         <div class="homehuge1-title">
									         
									         <?php if (($design == '4')&&($titlecolor == '2')){?> <!-- BLACK TITLE -->
									         <article id="post-<?php the_ID(); ?>" <?php post_class( 'cf' ); ?> role="article" class="blacktitle">
									         <?php } else { ?>
										       <article id="post-<?php the_ID(); ?>" <?php post_class( 'cf' ); ?> role="article">
									         <?php } ?>
								        
								            
									
									<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>">
										
									<h2 class="entry-title"><?php the_title(); ?></h2>
									

								<section class="block-excerpt">
									<?php if ( ! has_excerpt() ) {
										      echo '';
										} else { 
										      the_excerpt();
										}
										?>
								</section>
								</a>
								
							
									</p>
									
									<a href="#content">
											<?php if (($design == '4')&&($titlecolor == '2')){?> <!-- BLACK TITLE -->
											<img src="<?php echo get_template_directory_uri(); ?>/library/images/home-arrow-down-black.png">
											
											<?php } else { ?>
											<img src="<?php echo get_template_directory_uri(); ?>/library/images/home-arrow-down.png">
											<?php } ?>
											</a>
											
											
							</article>
							
							
								         </div>
								        </div>
									
								         </div>
							
								</div>
							
						
									    	
									  <?php
									endforeach; 
									wp_reset_postdata();
									$countpost=0;
									?>
									

			</section>