<?php if (have_posts()) : while (have_posts()) : the_post();
	$featuredImage = wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
	$vidtype = get_post_meta($post->ID, 'wpcf-video-type', true);
	$vidyoutube = get_post_meta($post->ID, 'wpcf-video-youtube-link', true);
	$vidvimeo = get_post_meta($post->ID, 'wpcf-video-vimeo-link', true);
	$vidfb = get_post_meta($post->ID, 'wpcf-video-facebook-code', true);
	$post_type_name = get_post_type( $post->ID );
	$post_type = get_post_type_object( get_post_type($post) );
	$embed_code = wp_oembed_get($vidyoutube);
	$embed_code2 = wp_oembed_get($vidvimeo);
	$embed_code3 = wp_oembed_get($vidfb);
	?>
	
			<?php get_header(); ?>
			
			<?php // Calling Youtube Data API.
				
				
				
$subscribers = file_get_contents('https://www.googleapis.com/youtube/v3/channels?part=statistics&id=UCraPOepRh_hgHEiZTSIilgw&key=AIzaSyB4ZmotWlZQN4GeoWZPQZNpBtlvRikgxwM');
// Decoding json response
$response = json_decode($subscribers, true );
// echoing subscribers count.
 $api_response_decoded = intval($response['items'][0]['statistics']['subscriberCount']);
 
 
// GET YOUTUBE ID
$url = $vidyoutube;
parse_str( parse_url( $url, PHP_URL_QUERY ), $my_array_of_vars );
$videoid = $my_array_of_vars['v'];
$apikey = 'AIzaSyB4ZmotWlZQN4GeoWZPQZNpBtlvRikgxwM';
 
 //GET VIDEO TITLE
$json = file_get_contents('https://www.googleapis.com/youtube/v3/videos?id='.$videoid.'&key='.$apikey.'&part=snippet');
$json2 = file_get_contents('https://www.googleapis.com/youtube/v3/videos?id='.$videoid.'&key='.$apikey.'&part=statistics');
$ytdata = json_decode($json);
$json_data = json_decode($json2, true);
$views = $json_data['items'][0]['statistics']['viewCount'];
 ?>



			<div id="content" class="nopadding">
				
				 <section class="post-hero post-hero-video">
				<div id="inner-content" class="wrap wrap-videopost cf">	
					
				
			  	
			  	<div class="m-all t-all d-all cf post-article-normal">
				  		
							<div class="post-video-area">
								<?php if($vidtype == '1' && !empty($vidyoutube)){ ?><?php echo $embed_code; ?><?php } ?>
								<?php if($vidtype == '2' && !empty($vidvimeo)){ ?><?php echo $embed_code2; ?><?php } ?>	
							</div>
							
							<?php if($vidtype == '1'){ ?>
								<div class="post-video-info"> 
								<h4><span>Watching Now</span> <?php echo $ytdata->items[0]->snippet->title; ?><span class="views"><?php echo $json_data['items'][0]['statistics']['viewCount']; ?> Views</span></h4>
														
							<h1 class="entry-title single-title" itemprop="name"><?php the_title(); ?></h1>
							
							    <?php if ( has_excerpt() ) { ?>
					    <p class="excerpt"><?php echo get_the_excerpt(); ?></p>
					<?php } else { ?>
					    
					<?php } ?>
					
							<a href="<?php echo $vidyoutube; ?>"><span class="youtube-link">Watch on Youtube</span></a>

							</div>
							
							<ul class="post-share post-share-video">
					  <li class="share-fb"><a href="http://www.facebook.com/sharer.php?u=<?php echo get_permalink(); ?>" target="_blank"><span></span></a></li>
					  	<li class="share-twitter"><a href="https://twitter.com/share?url=<?php echo get_permalink(); ?>" target="_blank"><span></span></a></li>
					  	<li class="share-pinterest"><a href="http://pinterest.com/pin/create/button/?url=<?php echo get_permalink(); ?>&media=<?php echo $featuredImage; ?>&description=<?php the_title();?>" target="_blank"><span></span></a></li>
<li class="share-comment"><a href="#comment"><span></span></a></li>
				  	</ul>
				  	
				  	
							<?php } ?>
							
						
						</div>
			  	</div>
		
			  	 </section>	
							
	<?php endwhile; ?>
<?php else : ?>
<?php endif; ?>

					<div id="inner-content" class="wrap wrap-videopost cf">				

					<main id="main" role="main" itemscope itemprop="mainContentOfPage" itemtype="http://schema.org/Blog">


						<?php if (have_posts()) : while (have_posts()) : the_post();
							$featuredImage = wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
							$design = get_post_meta($post->ID, 'wpcf-article-design', true); 
							 ?>
							 
							
							<?php get_template_part( 'post-design/format-video', get_post_format() ); ?>
							
							
							
							<div class="post-bottom-bar">
								<ul class="post-share-mobile">
					  	<li class="share-fb"><a href="http://www.facebook.com/sharer.php?u=<?php echo get_permalink(); ?>" target="_blank"><span></span></a></li>
					  	<li class="share-twitter"><a href="https://twitter.com/share?url=<?php echo get_permalink(); ?>" target="_blank"><span></span></a></li>
					  	<li class="share-pinterest"><a href="http://pinterest.com/pin/create/button/?url=<?php echo get_permalink(); ?>&media=<?php echo $featuredImage; ?>&description=<?php the_title();?>" target="_blank"><span></span></a></li>
<li class="share-comment"><a href="#comment"><span>Comments</span></a></li>


				  	</ul>
							</div>

						<?php endwhile; ?>

						<?php else : ?>

							<article id="post-not-found" class="hentry cf">
									<header class="article-header">
										<h1><?php _e( 'Oops, Post Not Found!', 'bonestheme' ); ?></h1>
									</header>
									<section class="entry-content">
										<p><?php _e( 'Uh Oh. Something is missing. Try double checking things.', 'bonestheme' ); ?></p>
									</section>
									<footer class="article-footer">
											<p><?php _e( 'This is the error message in the single.php template.', 'bonestheme' ); ?></p>
									</footer>
							</article>

						<?php endif; ?>

						
						
				
						
					</main>
					
					
					
				</div> <!-- end inner-content -->
				
				
				<?php include('template-morearticles.php');?>

			</div> <!-- end #content -->

<?php get_footer(); ?>


