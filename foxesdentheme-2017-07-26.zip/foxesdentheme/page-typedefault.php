<?php
/*
 Template Name: Post Type - Default
*/
?>

<?php get_header(); ?>
	
	<?php if(is_page( array('fashion') )){
			$taxposttype = 'fashion-post';
			$taxname = 'Fashion';
			$taxmenu = 'Menu-Fashion';
			$taxmenustyle = 'menu-fashion';
			$pageheadertype = 'page-header-fashion';
		} else if (is_page( array('beauty') )){ 
			$taxposttype = 'beauty-post';
			$taxname = 'Beauty';
			$taxmenu = 'Menu-Beauty';
			$taxmenustyle = 'menu-beauty';
			$pageheadertype = 'page-header-beauty';
		} else if (is_page( array('arts') )){ 
			$taxposttype = 'art';
			$taxname = 'Arts';
			$taxmenu = 'Menu-Arts';
			$taxmenustyle = 'menu-arts';
			$pageheadertype = 'page-header-arts';
		} else if (is_page( array('adulting') )){ 
			$taxposttype = 'adulting-post';
			$taxname = 'Adulting';
			$taxmenu = 'Menu-Adulting';
			$taxmenustyle = 'menu-adulting';
			$pageheadertype = 'page-header-adulting';
		} else if (is_page( array('lifestyle') )){ 
			$taxposttype = 'lifestyle-post';
			$taxname = 'Lifestyle';
			$taxmenu = 'Menu-Lifestyle';
			$taxmenustyle = 'menu-lifestyle';
			$pageheadertype = 'page-header-lifestyle';
		} else {
		 	$taxposttype = 'fashion-post';
			$taxname = 'All';
			$taxmenu = 'Menu-Quicklinks';
			$taxmenustyle = 'menu-fashion';
			$pageheadertype = 'page-header-fashion';
	 	} ?>
	
	<?php
								
		if ( get_query_var( 'paged' ) ) { $paged = get_query_var( 'paged' ); }
	elseif ( get_query_var( 'page' ) ) { $paged = get_query_var( 'page' ); }
	else { $paged = 1; }

				$countpost = 0;
				$args3 = array(
					'posts_per_page' => 6,
					'paged' => $paged,
					'order'=> 'DESC',
					'orderby' => 'date',
					'offset' => 7,
					'ignore_sticky_posts' => 1,
					'post_type' => array($taxposttype) 
				);
				
				$args4 = array(
					'posts_per_page' => 9,
					'paged' => $paged,
					'order'=> 'DESC',
					'orderby' => 'date',
					'ignore_sticky_posts' => 1,
					'post_type' => array($taxposttype) 
				);
				
				?>
				<?php if ($paged == 1){?>
					<?php $query = new WP_Query($args3); ?>
				<?php } ?>
				<?php if ($paged > 1){?>
					<?php $query = new WP_Query($args4); ?>
				<?php } ?>
				
				
	
	
			<div id="content" class="contentcategory">
				
				<?php include('template-fullscreen-banner.php');?>
				
				<div class="page-header-background">
				<div id="inner-content" class="wrap wrap-home-wide cf">
		
				
				<section class="page-header">
					
					<div class="page-header-title page-header-title-small <?php echo $pageheadertype; ?>">
						
	                  <?php $countfaq = 1; ?>
					  <h1 class="page-title"><?php echo $taxname; ?></h1>
	                <?php wp_nav_menu(array(
    					         'container' => false,                           // remove nav container
    					         'container_class' => $taxmenustyle,                 // class of container (should you choose to use it)
    					         'menu' 			=> $taxmenu   // nav name
						)); ?>
					</div>	
                  	</section>



								
				<!-- IF IS FIRST PAGE -->
				<?php if ($paged == 1){?>
					
					<section class="article-hero">
					
					
					<ul class="block-hero m-all t-all d-2of3 cf">
								
							<?php
									$countpost = 0;
									$args = array( 'posts_per_page' => 1, 'order'=> 'DESC', 'orderby' => 'date','post_type' => array($taxposttype), 'offset' => 0 );
									$postslist = get_posts( $args );
									foreach ( $postslist as $post ) :
									$content = get_the_content();
									$content = strip_tags($content);
									$contentshort = substr($content, 0, 255);
									$shortdescription = get_post_meta($post->ID, 'wpcf-short-description', true);
									$featuredImage = wp_get_attachment_url( get_post_thumbnail_id($post->ID));
									$post_type_name = get_post_type( $post->ID );
									$post_type = get_post_type_object( get_post_type($post) );
									$design = get_post_meta($post->ID, 'wpcf-article-design', true); 
									$largeimg = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'large', false, '' );
									$largeimgsrc = $largeimg[0];
									 $countpost++;
									  setup_postdata( $post ); ?> 
								
										  <li id="heroblock">
									  
									  
									  
						 	
						 	<?php
				                if(has_post_thumbnail()) { ?>
				                  
								 <a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>">

								<div id="blockimagecontainer">
									<?php 
										if( $design == 2 ) { ?>
										    <span class="videotag">Video</span>
										<?php } ?>

								<div id="blockimage" style="background-image: url('<?php echo $largeimgsrc; ?>');">	  </div>	
				
				            <?php } else { ?>
				             
				             	<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><div id="blockimagecontainer">
					             	<?php 
										if( $design == 2 ) { ?>
										    <span class="videotag">Video</span>
										<?php } ?>
										<div id="blockimage"></div>

				            <?php } ?>
							
							
							<article id="post-<?php the_ID(); ?>" <?php post_class( 'cf' ); ?> role="article">	            
									
									<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><h2 class="entry-title"><?php the_title(); ?></h2>
									

								<section class="block-excerpt">
									<?php the_excerpt(); ?>
								</section>
								
								<p class="byline entry-meta vcard">
										<?php
											$term_list = wp_get_post_terms($post->ID, 'fashion-category');
											$countterm = 1;
											?>
											<?php
											if ( ! empty( $term_list ) && ! is_wp_error( $term_list ) ){
										   
										    foreach ( $term_list as $term ) { 
										    
											     $term_link = get_term_link( $term );
    
											    // If there was an error, continue to the next term.
											    if ( is_wp_error( $term_link ) ) {
											        continue;
											    }
											
											    
											    echo '<a href="' . esc_url( $term_link ) . '">';
													echo '<span>' . $term->name . '</span>';
												 echo '</a>';
										       
										    }
										    
										    
										}
											$countterm = 1; ?>
											 <span class="time"><?php the_time('F j, Y'); ?></span>
									</p>
									
									
								</a>
								
								
							</article>
							
							</div></a>


							
							
										  </li>
							
									  
									  <?php
									endforeach; 
									wp_reset_postdata();
									?>
								
									
								</ul>
								
								
								
								<ul class="m-all t-1of3 d-1of3 cf tax-sidebar-banner">
								<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Kopifolks Banner Ad -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-6655377085080758"
     data-ad-slot="8968707821"
     data-ad-format="auto"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
								</ul>
								
								
								
								<ul class="block-std block-std-top last-col m-all t-all d-all cf">
								
							<?php
									$countpost = 0;
									$args = array( 'posts_per_page' => 6, 'order'=> 'DESC', 'orderby' => 'date','post_type' => array($taxposttype), 'offset' => 1 );
									$postslist = get_posts( $args );
									foreach ( $postslist as $post ) :
									$content = get_the_content();
									$content = strip_tags($content);
									$contentshort = substr($content, 0, 255);
									$shortdescription = get_post_meta($post->ID, 'wpcf-short-description', true);
									$featuredImage = wp_get_attachment_url( get_post_thumbnail_id($post->ID));
									$post_type_name = get_post_type( $post->ID );
									$post_type = get_post_type_object( get_post_type($post) );
									$design = get_post_meta($post->ID, 'wpcf-article-design', true); 
									$largeimg = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'large', false, '' );
									$largeimgsrc = $largeimg[0];
									 $countpost++;
									  setup_postdata( $post ); ?> 
								
										  <li>
									  
									  
									  
						 	
						 	<?php
				                if(has_post_thumbnail()) { ?>
				                  
								 <a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>">

								<div id="blockimagecontainer">
									<?php 
										if( $design == 2 ) { ?>
										    <span class="videotag">Video</span>
										<?php } ?>

								<div id="blockimage" style="background-image: url('<?php echo $largeimgsrc; ?>');">	  </div>	
				
				            <?php } else { ?>
				             
				             	<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><div id="blockimagecontainer">
					             	<?php 
										if( $design == 2 ) { ?>
										    <span class="videotag">Video</span>
										<?php } ?>
										<div id="blockimage"></div>

				            <?php } ?>
							
							
							<article id="post-<?php the_ID(); ?>" <?php post_class( 'cf' ); ?> role="article">	            
									
									<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><h2 class="entry-title"><?php the_title(); ?></h2>
									

								<section class="block-excerpt">
									<?php the_excerpt(); ?>
								</section>
								
								<p class="byline entry-meta vcard">
										<?php
											$term_list = wp_get_post_terms($post->ID, 'fashion-category');
											$countterm = 1;
											?>
											<?php
											if ( ! empty( $term_list ) && ! is_wp_error( $term_list ) ){
										   
										    foreach ( $term_list as $term ) { 
										    
											     $term_link = get_term_link( $term );
    
											    // If there was an error, continue to the next term.
											    if ( is_wp_error( $term_link ) ) {
											        continue;
											    }
											
											    
											    echo '<a href="' . esc_url( $term_link ) . '">';
													echo '<span>' . $term->name . '</span>';
												 echo '</a>';
										       
										    }
										    
										    
										}
											$countterm = 1; ?>
											 <span class="time"><?php the_time('F j, Y'); ?></span>
									</p>
									
									
								</a>
								
								
							</article>
							
							</div></a>


							
							
										  </li>
							
									  
									  <?php
									endforeach; 
									wp_reset_postdata();
									?>
								
									
								</ul>
								
								
							
							
								
				</section>
					
				<?php } ?>
				
				
					<!-- END FIRST PAGE -->	 	
				</div>
				</div>
				
				<?php if ($paged == 1){?>
				<!--<section class="category-adspace">
				<div id="inner-content" class="wrap wrap-home-wide cf">
					<div class="m-all t-all d-all cf">
						
					</div>
				</div>
				</section>-->
				
				<?php } ?>
				
				<div id="inner-content" class="wrap wrap-home-wide cf">
						<main id="main" class="m-all t-all d-all cf" role="main" itemscope itemprop="mainContentOfPage" itemtype="http://schema.org/Blog">
							
								<?php if ($paged == 1){?>
									<!--<h2 class="category-title" itemprop="headline">More Articles</h2>-->
									
									<?php } else { ?> 
									<h2 class="category-title" itemprop="headline">Beauty - Page <?php echo $paged;  ?></h2>
									<?php } ?>
									

						<ul class="block-std block-std-top">
								
							
																
								<?php  $countpost = 0; ?>
							
							<?php if ( $query->have_posts() ) : while ( $query->have_posts() ) : $query->the_post(); 
								$featuredImage = wp_get_attachment_url( get_post_thumbnail_id($post->ID));
								$design = get_post_meta($post->ID, 'wpcf-article-design', true); 
								$post_type_name = get_post_type( $post->ID );
								$post_type = get_post_type_object( get_post_type($post) );
								$shortdescription = get_post_meta($post->ID, 'wpcf-short-description', true);
								$largeimg = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'large', false, '' );
									$largeimgsrc = $largeimg[0];
								 $countpost++;
							?>
						 	
						 	
						 	
						 	  <li>
									  
									  
									  
						 	
						 	<?php
				                if(has_post_thumbnail()) { ?>
				                  
								 <a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>">

								<div id="blockimagecontainer">
									<?php 
										if( $design == 2 ) { ?>
										    <span class="videotag">Video</span>
										<?php } ?>

<div id="blockimage" style="background-image: url('<?php echo $largeimgsrc; ?>');"></div></div></a>		 
				
				            <?php } else { ?>
				             
				             	<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><div id="blockimagecontainer">
					             	<?php 
										if( $design == 2 ) { ?>
										    <span class="videotag">Video</span>
										<?php } ?>
										<div id="blockimage"></div></div></a>	

				            <?php } ?>



							<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><article id="post-<?php the_ID(); ?>" <?php post_class( 'cf' ); ?> role="article">	            
									
									<h2 class="entry-title"><?php the_title(); ?></h2>
									

								
									<?php if ( ! has_excerpt() ) { ?>
										 <section class="block-excerpt"><?php the_excerpt(); ?></section> 
										<? } else {  ?>
										      <section class="block-excerpt"><?php the_excerpt(); ?></section> 
										<?php } ?>
								
								
								
								<p class="byline entry-meta vcard">
										<?php
											$term_list = wp_get_post_terms($post->ID, 'fashion-category');
											$countterm = 1;
											?>
											<?php
											if ( ! empty( $term_list ) && ! is_wp_error( $term_list ) ){
										   
										    foreach ( $term_list as $term ) { 
										    
											     $term_link = get_term_link( $term );
    
											    // If there was an error, continue to the next term.
											    if ( is_wp_error( $term_link ) ) {
											        continue;
											    }
											
											    
											    echo '<a href="' . esc_url( $term_link ) . '">';
											    
											    if($term->name == 'PS4'){
													 echo '<span class="cat-ps4">' . $term->name . '</span>';
												} else if($term->name == 'Switch'){
													 echo '<span class="cat-switch">' . $term->name . '</span>';
												} else if($term->name == 'Xbox One'){
													 echo '<span class="cat-xbox">' . $term->name . '</span>';
												} else {
													echo '<span>' . $term->name . '</span>';
												}
												
												 echo '</a>';
										       
										    }
										    
										    
										}
											$countterm = 1; ?>
                                     <span class="time"><?php the_time('F j, Y'); ?></span>
									</p>
							</article></a>
							
							
										  </li>						 	
						 	
										  			 	
						 	
						 	
						 	
							 <?php endwhile; ?>
									<!-- pagination -->
									<div class="pagination-custom">
									<?php 
									previous_posts_link('< Previous');
								    next_posts_link( 'More Articles >', $query->max_num_pages );
									
								    wp_reset_postdata();	
									?>
									</div>
									<?php else : ?>
									<!-- No posts found -->
									<?php $countpost=0; endif; ?>
		
									</ul>


							
							
							
						</main>
				</div>
				
				
				<section class="footer-sidebar">
					<div id="inner-content" class="wrap wrap-home-wide cf">
					<div id="sidebar-all" class="m-all t-all d-all cf">
						<?php get_sidebar('category'); ?>



						</div>
					</div>
				</section>
				
				

			</div>

<?php get_footer(); ?>
