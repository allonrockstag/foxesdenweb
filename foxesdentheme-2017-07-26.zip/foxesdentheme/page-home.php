<?php
/*
 Template Name: Home
*/
?>
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

<?php $homedesign = get_post_meta($post->ID, 'wpcf-home-design', true); ?>

<?php if($homedesign =='2'){ ?>
	<?php get_header('huge2'); ?>
<?php } else { ?>
	<?php get_header('huge'); ?>
<?php } ?>




 <?php endwhile; ?>
								
<?php else : ?>

<?php endif; ?>
							
<?php 
	
	if ( get_query_var( 'paged' ) ) { $paged = get_query_var( 'paged' ); }
					elseif ( get_query_var( 'page' ) ) { $paged = get_query_var( 'page' ); }
					else { $paged = 1; }
					
					
					
					
					?>
					
					
			<?php if($homedesign =='2') { ?>
				
				<?php include('template-homehuge2.php');?>
			
			<?php } ?> <!-- end homedesign -->
			
			
			<?php if($homedesign =='2') { ?>
				<div id="content" class="content-huge2">
			<?php } else { ?>
				<div id="content" class="content-huge">
			<?php } ?>
			
			
			<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
			<?php 
				$adtype = get_post_meta($post->ID, 'wpcf-ad-type', true); 
				$adfullscreenimg = get_post_meta($post->ID, 'wpcf-ad-fullscreen-image', true); 
				$adfullscreenlink = get_post_meta($post->ID, 'wpcf-ad-fullscreen-link', true); 
				$adlinktitle = get_post_meta($post->ID, 'wpcf-ad-link-title', true); 
				$adfullscreenlargeimg = get_post_meta($post->ID, 'wpcf-ad-fullscreen-large-image', true);
				$homedesign = get_post_meta($post->ID, 'wpcf-home-design', true);
			?>
							
								
								<?php if( $adtype == 2 ) { ?>
						
						<section class="ad-fullscreen" style="background-image: url('<?php echo $adfullscreenimg; ?>');">
							<a href="<?php echo $adfullscreenlink; ?>" title="<?php echo $adlinktitle;?>"><div class="ad-fullscreen-content"> 
							
							</div></a>
						</section>

							<?php } else if($adtype == 3) { ?>
								<section class="ad-fullscreen-large" style="background-image: url('<?php echo $adfullscreenlargeimg; ?>');">
							<a href="<?php echo $adfullscreenlargelink; ?>" title="<?php echo $adlinktitle;?>"><div class="ad-fullscreen-content"> 
							
							</div></a>
						</section>
						
							<?php } else { ?>
						
							<?php } ?>
			

				

							<?php endwhile; ?>
								
							<?php else : ?>

							<?php endif; ?>
								
								
								
						
					
					
					
		<!--<section class="transparent-banner banner-home-1">
						<div class="banner-type-leaderboard banner-desktop">This is an Ad Space</div> 	
					</section>-->


				
			<?php if($homedesign == '2') { ?>
				
				<?php include('template-homehuge2a.php');?>
			
			<?php } else { ?> <!-- end homedesign -->
			
				<?php include('template-homehuge1.php');?>
			<?php } ?>
								
				
				<section class="home-latest">
					
					<div id="inner-content" class="wrap wrap-home-wide">
						
						
						<div class="special-title">
									<h2>More Stories</h2>
								</div>
								
								
						<ul class="block-std block-std-top">
								
					
					
									<?php 
									
									$sticky_posts = get_option( 'sticky_posts' );
									$args = array(
									'posts_per_page' => 6,
									'paged' => $paged,
									'order'=> 'DESC',
									'post__not_in'  => array($sticky_posts,$post1,$post2,$post3) ,
									'orderby' => 'date',
									'post_type' => array('post','fashion-post','beauty-post','art','lifestyle-post','adulting-post')
									);
									$query = new WP_Query($args);
									?>


							<?php if ($query->have_posts()) : while ($query->have_posts()) : $query->the_post(); 
								$content = get_the_content();
									$content = strip_tags($content);
									$contentshort = substr($content, 0, 255);
									$shortdescription = get_post_meta($post->ID, 'wpcf-short-description', true);
									$featuredImage = wp_get_attachment_url( get_post_thumbnail_id($post->ID));
									$post_type_name = get_post_type( $post->ID );
									$post_type = get_post_type_object( get_post_type($post) );
									$design = get_post_meta($post->ID, 'wpcf-article-design', true); 
									$largeimg = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'medium', false, '' );
									$largeimgsrc = $largeimg[0]; 
									 $countpost++;
							?>
							
							
					
								
									<li>
									  
									  
									  
						 	
						 	<?php
				                if(has_post_thumbnail()) { ?>
				                  
								 <a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>">

								<div id="blockimagecontainer">
									<?php 
										if( $design == 2 ) { ?>
										    <span class="videotag">Video</span>
										<?php } ?>

<div id="blockimage" style="background-image: url('<?php echo $largeimgsrc; ?>');"></div></div></a>		 
				
				            <?php } else { ?>
				             
				             	<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><div id="blockimagecontainer">
					             	<?php 
										if( $design == 2 ) { ?>
										    <span class="videotag">Video</span>
										<?php } ?>
										<div id="blockimage"></div></div></a>	

				            <?php } ?>



							<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><article id="post-<?php the_ID(); ?>" <?php post_class( 'cf' ); ?> role="article">	            
									
									<h2 class="entry-title"><?php the_title(); ?></h2>
									

								
									<?php if ( ! has_excerpt() ) { ?>
										 <section class="block-excerpt"><?php the_excerpt(); ?></section> 
										<? } else {  ?>
										      <section class="block-excerpt"><?php the_excerpt(); ?></section> 
										<?php } ?>
								
								
								
								<p class="byline entry-meta vcard">
										
									<?php $countterm = 1; ?>
										<?php if( get_post_type() == 'fashion-post' ) { ?>
											<?php $term_list = wp_get_post_terms($post->ID, 'fashion-category'); ?>
										<?php } else if( get_post_type() == 'beauty-post' ) { ?>
											<?php $term_list = wp_get_post_terms($post->ID, 'beauty-category'); ?>
										<?php } else if( get_post_type() == 'art' ) { ?>
											<?php $term_list = wp_get_post_terms($post->ID, 'art-category'); ?>
										<?php } else if( get_post_type() == 'lifestyle-post' ) { ?>
											<?php $term_list = wp_get_post_terms($post->ID, 'lifestyle-category'); ?>
										<?php } else if( get_post_type() == 'adulting-post' ) { ?>
											<?php $term_list = wp_get_post_terms($post->ID, 'adulting-category'); ?>
										<?php } else if( get_post_type() == 'video' ) { ?>
											<?php $term_list = wp_get_post_terms($post->ID, 'video-category'); ?>
										<?php } else { ?>
										<?php $term_list = wp_get_post_terms($post->ID, 'category'); ?>
										<?php } ?>
										
										
										
												
										
										<?php if( get_post_type() == 'fashion-post'){ ?>
											<?php 	echo '<a href="';
													echo get_home_url();
													echo '/fashion';
													echo '">';
													echo '<span>' . 'Fashion' . '</span>';
													echo '</a>';
												?>
										<?php } else if (get_post_type() == 'beauty-post'){ ?>
											<?php 	echo '<a href="';
													echo get_home_url();
													echo '/beauty';
													echo '">';
													echo '<span>' . 'Beauty' . '</span>';
													echo '</a>';
												?>
										<?php } else if ( get_post_type() == 'arts-post'){ ?>
											<?php 	echo '<a href="';
													echo get_home_url();
													echo '/arts';
													echo '">';
													echo '<span>' . 'Arts' . '</span>';
													echo '</a>';
												?>
										<?php } else if (get_post_type() == 'lifestyle-post'){ ?>
											<?php 	echo '<a href="';
													echo get_home_url();
													echo '/lifestyle';
													echo '">';
													echo '<span>' . 'Lifestyle' . '</span>';
													echo '</a>';
												?>
										<?php } else if (get_post_type() == 'adulting-post'){ ?>
											<?php 	echo '<a href="';
													echo get_home_url();
													echo '/adulting';
													echo '">';
													echo '<span>' . 'Adulting' . '</span>';
													echo '</a>';
												?>
										<?php } else if (get_post_type() == 'video'){ ?>
											<?php 	echo '<a href="';
													echo get_home_url();
													echo '/video';
													echo '">';
													echo '<span>' . 'Video' . '</span>';
													echo '</a>';
												?>
										<?php } else { ?>
											<?php
												if ( ! empty( $term_list ) && ! is_wp_error( $term_list ) ){
												    foreach ( $term_list as $term ) { 
													 	$term_link = get_term_link( $term );
													    // If there was an error, continue to the next term.
													    if ( is_wp_error( $term_link ) ) {
													        continue;
													    } 
														 echo '<a href="' . esc_url( $term_link ) . '">';   
														 echo '<span>' . $term->name . '</span>';
														 echo '</a>';		
												    }
												}
											?>
										<?php } ?>


										<?php $countterm = 1; ?>
                                     <span class="time"><?php echo meks_time_ago(); /* post date in time ago format */ ?></span>
									</p>
							</article></a>
							
							
										  </li>	
							
							
							<?php endwhile; ?>
							<!-- pagination -->
							
							<?php else : ?>
							<!-- No posts found -->
							<?php endif;
								wp_reset_postdata(); ?>
								
								
									
								</ul>	
						
						
						
					</div>
				</section>
				
				
				<!--<section class="filter-sidebar">
					<div id="inner-content" class="wrap wrap-home-wide">
					<?php get_sidebar('filters'); ?>
					</div>
				</section>-->
					
					
					<section class="home-foodguide">
						<div id="inner-content" class="wrap wrap-home-wide wrap-guide-wide">
							
							<h2 class="section-title">Latest Videos</h2>
							
														
							<ul class="home-guide">
								
								<button id="left-button" class="invisible">
        <i class="fa fa-angle-left" aria-hidden="true"></i>
      </button>
      <button id="right-button">
        <i class="fa fa-angle-right" aria-hidden="true"></i>
      </button>

									
																
								<?php  $countpost = 0; ?>
							
							<?php
									$countpost = 0;
									$args = array(
									'posts_per_page' => 8,
									'order'=> 'DESC',
									'orderby' => 'date',
									'post_type' => array('video'),
									'offset' => 0 );
									$postslist = get_posts( $args );
									foreach ( $postslist as $post ) :
									$featuredImage = wp_get_attachment_url( get_post_thumbnail_id($post->ID));
									$largeimg = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'medium', false, '' );
									$largeimgsrc = $largeimg[0]; 
									$design = get_post_meta($post->ID, 'wpcf-article-design', true); 
									 $countpost++;
									  setup_postdata( $post ); ?> 


						 	
						 	 	  <li>
						 	 	  
						 	 	  <?php if (!empty($largeimgsrc)){?>
							 	 	  
							 	 	   <a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>">

								<div id="blockimagecontainer">
									<?php if( $design == 2 ) { ?><span class="videotag">Video</span><?php } ?><div id="blockimage" style="background-image: url('<?php echo $largeimgsrc; ?>');"></div>


						 	 	  <?php } else { ?>
						 	 	  <a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><div id="blockimagecontainer">
					             	<?php if( $design == 2 ) { ?><span class="videotag">Video</span>
										<?php } ?>
										<div id="blockimage" style="background-image: url('<?php bloginfo( 'template_url' ); ?>/library/images/guide-kopifolks.jpg');"><h2><?php the_title(); ?></h2></div>
										
										
						 	 	  <?php } ?>
							 
								
				             <article id="post-<?php the_ID(); ?>" <?php post_class( 'cf' ); ?> role="article">	            
									<span>
									<h2 class="entry-title"><?php the_title(); ?></h2>
									</span>						
							</article>
							
							</div></a>	
				             	
										
										
										
										</li>
						 	

						 	
									  <?php
									endforeach;
									wp_reset_postdata();
									?>
									
									  <li class="end">
						
				             
				             	
					             	<div id="blockimagecontainer"><div id="blockimage">
						             	<a href="<?php echo get_home_url(); ?>/videos" rel="bookmark" title="Kopifolks Food Guide"><span class="more">More</span></a>
						             	</div></div>
					             		

								</li>

								 
							</ul>

							<a href="<?php echo get_home_url(); ?>/videos" rel="bookmark" title="Kopifolks Food Guide"><span class="home-guide-more">Explore Videos</span></a>
						</div>
					</section>
				
				<section class="home-footer">
					<div id="inner-content" class="wrap cf">
						<div class="m-all t-all d-all last-col cf">
							<div class="home-footer-box">
							<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
							<?php
								$instabox = get_post_meta($post->ID, 'wpcf-instagram-box', true); 
								$fbbox = get_post_meta($post->ID, 'wpcf-facebook-box', true); 
								$youtubebox = get_post_meta($post->ID, 'wpcf-youtube-box', true); 
							?>
									
									<?php the_content(); ?>
			

				

							<?php endwhile; ?>
								
							<?php else : ?>

							<?php endif; ?>
							</div>
								
						</div>
						<div class="m-all t-all d-1of3 cf">
							<div class="home-footer-box">
							<?php echo apply_filters('the_content',$fbbox); ?>
							</div>
						</div>
						<div class="m-all t-all d-1of3 cf">
							<div class="home-footer-box">
							<?php echo apply_filters('the_content',$instabox); ?>
							</div>
						</div>
						<div class="m-all t-all d-1of3 last-col cf">
							<div class="home-footer-box">
							<?php echo apply_filters('the_content',$youtubebox); ?>
							</div>
						</div>
					</div>
				</section>
						
				<!--	<section class="youtube-banner youtube-banner-home">
					
					
						<div class="youtube-banner-container" style="background-image: url('<?php echo get_template_directory_uri(); ?>/library/images/fxd-backdrop.jpg');">
							<a href="https://youtube.com/kopifolks"><div class="youtube-banner-overlay">
								<article>
									<img src="<?php echo get_template_directory_uri(); ?>/library/images/foxesden-logo-white.png">
							<p>Subscribe to our Youtube Channel</p>
							</article>
							</div>
							</a>
						</div>
					
				</section>
				-->

			</div>

<?php get_footer(); ?>
